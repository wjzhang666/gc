// indes.js

// 定义一个总毫秒数，以一天为例
// var total_micro_second = 3600 * 1000*24;//这是一天倒计时
var util = require('../../utils/util.js');
let app = getApp(); 
Page({

  data: {
    datetimeTo: "2020/07/07", // 秒杀开始时间
    plan:"距离2020高考",
    timeLeft: "loading" ,   // 剩下的时间（天时分秒）初始化下是loading
    show:true,
    lizhi:false,
    array:['任何知识都不能带给你好运，但是它们能让你悄悄的成为你自己。','放弃很简单，但你坚持到底你样子一定很酷！','同是寒窗苦读，怎愿甘拜下风','所谓的光辉岁月，并不是以后，闪耀的日子，而是无人问津时，你对梦想的偏执。','总有人会成功，为什么不能是你呢？','我们一路奋战，不是为了改变世界，而是为了不让世界改变我们。','值得拥有的东西，永远都来之不易。',' 有志者自有千计万计，无志者只感千难万难。','闻鸡起舞成就拼搏劲旅师；天道酬勤再现辉煌王者风。','今日寒窗苦读，必定有我；明朝独占熬头，舍我其谁？',' 行动是成功的阶梯，行动越多，登得越高。','明天的你一定会感谢现在拼命的自己。','点击这里获取隐藏福利','天下断无易处之境遇；人间哪有空闲的光阴。','含泪播种的人一定能含笑收获。','只求“少丢分”，不说“得高分”！','有动力而无压力，紧张而不焦虑，迅速而不慌乱。','试试就能行，争争就能赢。','争取时间就是争取成功，提高效率就是提高分数。','积一时之跬步，臻千里之遥程。','总想赢者必输，不怕输者必赢。','更快、更高、更强。','最难的题，对你而言，并不一定在于最后一道。'],
    index:-1,
    motto:'明天的你一定会感谢现在拼命的自己。'
  },



//  获取输入的时间
  timechange:function(e){
    this.setData({ datetimeTo: e.detail.value })
    wx.setStorageSync('datetimeTo', this.data.datetimeTo)
    console.log(111)
    },


// 获取输入的计划
  changeplan:function(e){
    this.setData({ plan: e.detail.value })
    wx.setStorageSync('plan', this.data.plan)
    console.log(222)
  },  


// 改变励志语
  changemotto:function(){
    this.setData({
      motto:this.data.array[++this.data.index]
      
    });
    if(this.data.index==this.data.array.length-1)
      this.setData({index:-1});
  },


  onShow: function () {
    // 
    // 时间变了，计划没改变
    var datetimeTo = wx.getStorageSync('datetimeTo')
    if (datetimeTo) {
      
      this.setData({ datetimeTo: datetimeTo  })
      console.log(1)
    };

    var plan = wx.getStorageSync('plan')
    if (plan) {
      this.setData({ plan: plan });
      console.log(2)
    };
   
    // 
    this.data.timer = setInterval(() =>{ //注意箭头函数！！
      this.setData({
        timeLeft: util.getTimeLeft(this.data.datetimeTo)//使用了util.getTimeLeft
      });
      if (this.data.timeLeft == "0天0时0分0秒") {
        clearInterval(this.data.timer);
      }
    }, 1000);
  },
  showShareMenu() {
    wx.showShareMenu();
      this.setData({
        show: true
      })
      console.log("显示了当前页面的转发按钮");
  },

  // wx.hideShareMenu()关闭分享按钮 此时再点击右上角的分享按钮 会弹出 当前页面未设置分享 字样
  hideShareMenu() {
      wx.hideShareMenu();
      this.setData({
        show: false
      })
      console.log("隐藏了当前页面的转发按钮");
  
  },

  
    //分享显示图标程序段
  onShareAppMessage: (res) => {
    if (res.from === 'button') {
      console.log("来自页面内转发按钮"); 
      console.log(res.target);
    }
    else {
      console.log("来自右上角转发菜单")
    }


    return {
      title: '分享给你一个好用的小程序',
      path: '/pages/index/index?id=123',
      //这里的path是当前页面的path，必须是以 / 开头的完整路径，后面拼接的参数 是分享页面需要的参数  不然分享出去的页面可能会没有内容
      imageUrl: "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=3450423995,2541621936&fm=26&gp=0.jpg",
      desc: '高考倒计时',

      // 转发成功与失败
      success: (res) => {
        console.log("转发成功", res);
        console.log("成功了")
      },
      fail: (res) => {
        console.log("转发失败", res);
      }
    }
  }
});
