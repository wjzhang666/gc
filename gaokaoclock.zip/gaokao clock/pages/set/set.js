// pages/set/set.js
var util = require('../../utils/util.js');
let app = getApp(); 
Page({
  data: {
    datetimeTo: "2020/07/07", // 秒杀开始时间
    plan:"距离2020高考",
    school:"",
    major:""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  // changeming:function(e){
  //   this.setData({ ming: e.detail.value })
  //   wx.setStorageSync('ming', this.data.ming)
  //   console.log(111222111)
  // },

////////
  

  //  获取输入的学校
  schoolchange:function(e){
    this.setData({ school: e.detail.value })
    },
  yuanxiao:function(){
    wx.setStorageSync('school', this.data.school)
    console.log(111222)
  },
  // 获取输入的专业
  changemajor:function(e){
    this.setData({ major: e.detail.value })
    
  },  
  zhuanye:function(){
    wx.setStorageSync('major', this.data.major)
    console.log(222111)
  },
    
  //  获取输入的时间
  timechange:function(e){
    this.setData({ datetimeTo: e.detail.value })
    
    },
  shijian:function(){
    wx.setStorageSync('datetimeTo', this.data.datetimeTo)
    console.log(111)
  },

  // 获取输入的计划
  changeplan:function(e){
    this.setData({ plan: e.detail.value })   
  },  
  jihua:function(){
    wx.setStorageSync('plan', this.data.plan)
    console.log(222)
  },
  
  // 个性签名
  changeming:function(e){
    this.setData({ ming: e.detail.value })
  },
  qianming:function(){
    wx.setStorageSync('ming', this.data.ming)
    console.log(111222111)
  },
  onShow: function () {
    // 
    // 时间变了，计划改变
    var ming = wx.getStorageSync('ming')
    if (ming) {
      
      this.setData({ ming: ming  })
      console.log(112221)
    };

    var major = wx.getStorageSync('major')
    if (major) {
      
      this.setData({ major: major  })
      console.log(112)
    };

    var school = wx.getStorageSync('school')
    if (school) {
      this.setData({ school: school });
      console.log(221)
    };
    var datetimeTo = wx.getStorageSync('datetimeTo')
    if (datetimeTo) {
      
      this.setData({ datetimeTo: datetimeTo  })
      console.log(1)
    };

    var plan = wx.getStorageSync('plan')
    if (plan) {
      this.setData({ plan: plan });
      console.log(2)
    };
   
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: (res) => {
    if (res.from === 'button') {
      console.log("来自页面内转发按钮"); 
      console.log(res.target);
    }
    else {
      console.log("来自右上角转发菜单")
    }


    return {
      title: '分享给你一个好用的小程序',
      path: '/pages/index/index?id=123',
      //这里的path是当前页面的path，必须是以 / 开头的完整路径，后面拼接的参数 是分享页面需要的参数  不然分享出去的页面可能会没有内容
      imageUrl: "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=3450423995,2541621936&fm=26&gp=0.jpg",
      desc: '高考倒计时',

      // 转发成功与失败
      success: (res) => {
        console.log("转发成功", res);
        console.log("成功了")
      },
      fail: (res) => {
        console.log("转发失败", res);
      }
    }
  }
})