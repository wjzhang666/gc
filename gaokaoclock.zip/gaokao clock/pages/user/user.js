//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    school:'例：清华大学',
    major:'例：计算机技术',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  // 个性签名
  changeming:function(e){
    this.setData({ ming: e.detail.value })
    wx.setStorageSync('ming', this.data.ming)
    console.log(111222111)
  },

////////
  

  //  获取输入的学校
  schoolchange:function(e){
    this.setData({ school: e.detail.value })
    wx.setStorageSync('school', this.data.school)
    console.log(111222)
    },
  // 获取输入的专业
  changemajor:function(e){
    this.setData({ major: e.detail.value })
    wx.setStorageSync('major', this.data.major)
    console.log(222111)
  },  

  onShow: function () {
    // 
    // 时间变了，计划改变
    var ming = wx.getStorageSync('ming')
    if (ming) {
      
      this.setData({ ming: ming  })
      console.log(112221)
    };

    var major = wx.getStorageSync('major')
    if (major) {
      
      this.setData({ major: major  })
      console.log(112)
    };

    var school = wx.getStorageSync('school')
    if (school) {
      this.setData({ school: school });
      console.log(221)
    };
  
  },
  onLoad: function () {
     // 查看是否授权
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  onShareAppMessage: (res) => {
    if (res.from === 'button') {
      console.log("来自页面内转发按钮"); 
      console.log(res.target);
    }
    else {
      console.log("来自右上角转发菜单")
    }


    return {
      title: '分享给你一个好用的小程序',
      path: '/pages/index/index?id=123',
      //这里的path是当前页面的path，必须是以 / 开头的完整路径，后面拼接的参数 是分享页面需要的参数  不然分享出去的页面可能会没有内容
      imageUrl: "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=3450423995,2541621936&fm=26&gp=0.jpg",
      desc: '高考倒计时',

      // 转发成功与失败
      success: (res) => {
        console.log("转发成功", res);
        console.log("成功了")
      },
      fail: (res) => {
        console.log("转发失败", res);
      }
    }
  }
})
